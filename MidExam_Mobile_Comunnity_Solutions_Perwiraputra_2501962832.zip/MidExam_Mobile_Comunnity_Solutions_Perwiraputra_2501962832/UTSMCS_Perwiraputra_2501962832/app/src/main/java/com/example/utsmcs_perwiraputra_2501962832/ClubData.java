package com.example.utsmcs_perwiraputra_2501962832;

import java.util.ArrayList;

public class ClubData {
    private static String [] clubName ={
            "Arsenal",
            "Aston Villa",
            "Chelsea",
            "Burnley",
            "Manchester United",
            "Manchester City",
            "Newcastle United",
            "Liverpool",
            "Southampton",
            "Brighton & Hove Albion",
            "Crystal Palace",
            "Leicester City",
            "Leeds United",
            "Sheffield United",
            "Tottenham Hotspur",
            "West Bromwich Albion",
            "West Ham United FC",
            "Wolverhampton Wanderers",
            "Everton",
            "Fullham"

    };

    private static String [] clubDetail = {
            "Arsenal Football Club adalah klub sepak bola profesional Inggris yang berbasis di daerah Holloway, London. Didirikan pada 1886 dengan nama Dial Square. Klub ini bermain di Liga Utama Inggris yang termasuk salah satu klub tersukses di sepak bola Inggris, yang telah memenangkan 13 gelar kasta utama Liga Inggris (10 pada era Divisi Pertama dan 3 pada era Premier League) dan menjadi club pemenang gelar Piala FA paling banyak.",
            "Aston Villa Football Club juga dikenal sebagai Villa, The Villa, The Villans dan The Lions adalah klub sepak bola profesional yang bermarkas di Villa Park, Birmingham, Inggris. Klub ini bermain di Liga Utama Inggris dan merupakan salah satu klub pendiri Liga Sepak Bola (Football League) pada tahun 1888 serta Liga Utama Inggris pada tahun 1992. Aston Villa merupakan salah satu klub tertua di Inggris.",
            "Chelsea Football Club adalah sebuah klub sepak bola profesional yang bermarkas di Fulham, London. Didirikan pada 1905, klub ini kini berkompetisi di Liga Utama Inggris dan memainkan pertandingan kandang mereka di Stamford Bridge.[1][4] Chelsea merupakan salah satu klub sepak bola tersukses di Inggris, dengan telah memenangkan lebih dari tiga puluh gelar juara kompetisi klub domestik dan internasional.",
            "Burnley Football Club adalah sebuah klub sepak bola Inggris yang bermarkas di Burnley, Lancashire. Klub ini sedang bermain di Kejuaraan EFL, kasta kedua sepak bola inggris di Musim 2022-23 setelah didegradasi dari Liga utama inggris di musim sebelumnya. Klub ini memainkan pertandingan kandangnya di stadion Turf Moor yang berkapasitas 22.546 penonton. Seragam mereka adalah berwarna nila, sehingga mereka dijuluki Clarets. Klub ini adalah salah satu anggota penemu English Football League pada tahun 1888.",
            "Manchester United Football Club adalah sebuah klub sepak bola profesional yang berbasis di Old Trafford, Manchester Raya, yang bermain di Liga Utama Inggris dengan gelar Liga Utama Inggris terbanyak sepanjang masa. Didirikan sebagai Newton Heath LYR Football Club pada tahun 1878, klub ini berganti nama menjadi Manchester United pada 1902 dan pindah ke Old Trafford pada tahun 1910.",
            "Manchester City Football Club adalah sebuah klub sepak bola profesional dari Inggris yang bermain di Liga Premier Inggris. Klub ini merupakan klub sekota dengan Manchester United dan bermarkas di Stadion Etihad, Manchester.",
            "Newcastle United Football Club adalah klub sepak bola profesional Inggris, yang berbasis di Newcastle upon Tyne, yang bermain di Liga Utama Inggris – divisi teratas sepak bola Inggris. Klub ini didirikan pada tahun 1892 melalui penggabungan Newcastle East End dan Newcastle West End. Mereka memainkan pertandingan kandang mereka di Stadion St James' Park di pusat kota Newcastle. Mengikuti persyaratan Taylor Report bahwa semua klub Liga Utama harus memiliki stadion all-seater, kemudian stadion tersebut dikembangkan pada pertengahan 1990-an dan saat ini memiliki kapasitas 52.305.",
            "Liverpool Football Club adalah sebuah klub sepak bola profesional asal Inggris yang berbasis di Liverpool. Didirikan pada tahun 1892, Liverpool kemudian bergabung dengan Football League di tahun berikutnya dan sejak pembentukannya memainkan pertandingan kandang mereka di Stadion Anfield yang terletak sekitar 4,8 km dari pusat kota.",
            "Southampton Football Club merupakan sebuah tim sepak bola profesional Inggris yang berbasis di Southampton, (Hampshire), dan bermain di Liga Utama Inggris. Sejak tahun 2001 klub ini memainkan pertandingan kandangnya di (Stadion St Mary's), sebelumnya mereka memainkan pertandingan kandang di Stadion The Dell.",
            "Brighton & Hove Albion Football Club adalah sebuah klub sepak bola profesional asal Inggris yang berbasis di kota pantai Brighton & Hove, di timur Sussex. Sering disebut sebagai Brighton & Hove Albion atau hanya sekadar sebagai Brighton. Saat ini bermain di Liga Utama Inggris, tingkat pertama dari sistem liga sepak bola Inggris, menggelar pertandingan di Stadion Falmer berpakasitas 30.750 penonton.",
            "Crystal Palace Football Club merupakan sebuah tim sepak bola Inggris yang bermarkas di London Borough of Croydon dan didirikan pada tahun 1905. Klub ini memainkan pertandingan kandangnya di Selhurst Park yang berkapasitas 26.309 penonton. Seragam mereka berwarna merah-biru.",
            "Leicester City Football Club Dibentuk pada tahun 1884 oleh sekelompok pemuda Wyggeston School sebagai \"Leicester Fosse\", klub bergabung dengan Asosiasi Sepak Bola Inggris pada tahun 1890. Sebelum pindah ke Jalan Filbert pada tahun 1891, klub bermain di lima tempat yang berbeda, termasuk Victoria Park sebelah tenggara dari pusat kota dan di Belgrave Road Cricket and Bicycle Grounds.",
            "Leeds United adalah sebuah klub sepak bola asal Inggris yang berbasis di Beeston, Leeds, West Yorkshire. Pada akhir musim 2019–20, mereka mampu menjadi juara Kejuaraan EFL, sehingga akan promosi ke Liga Utama Inggris pada musim selanjutnya. Sebelumnya mereka telah menghabiskan sebagian besar sejarah mereka di tingkat atas sepak bola Inggris yaitu Liga Utama Inggris. Klub ini dibentuk pada tahun 1919 menyusul pembubaran tim pendahulunya Leeds City FC oleh The Football League.",
            "Sheffield United Football Club adalah sebuah tim sepak bola profesional Inggris yang bermarkas di kota Sheffield, Yorkshire Selatan, Inggris. Tim ini dibentuk tahun 1889. Saat ini klub Sheffield United bermain di Liga Utama Inggris, kompetisi tingkat ke-1 dalam sistem liga sepak bola Inggris. Mereka adalah tim olahraga pertama yang menggunakan nama 'United' dan dijuluki The Blades, berkat reputasi kota Sheffield yang mendunia untuk produksi baja.",
            "Tottenham Hotspur Football Club adalah klub sepak bola yang berasal dari Tottenham, sebuah daerah yang berada di wilayah utara London. Mereka juga dikenal sebagai Spurs, The Spurs dan Tottenham, sementara penggemar mereka memberi mereka nama the Lilywhites karena seragam tradisional mereka yang berwarna putih.",
            "West Bromwich Albion Football Club adalah sebuah klub sepak bola Inggris yang bermarkas di West Bromwich, West Midlands. Didirikan pada tahun 1878. Sejak tahun 1900, klub ini memainkan pertandingan kandangnya di Stadion The Hawthorns yang berkapasitas 26.484 penonton. Seragam mereka adalah biru-putih sehingga mereka dijuluki The Baggies.",
            "West Ham United Football Club adalah sebuah klub sepak bola Inggris yang bermarkas di London. Sejak 2016, klub ini memainkan pertandingan kandangnya di Stadion London yang berkapasitas 60.000 kursi. Sebelumnya Hammers bermain di Boleyn Ground. Seragam mereka berwarna merah-biru.",
            "Wolverhampton Wanderers Football Club adalah sebuah klub sepak bola Inggris yang bermarkas di Wolverhampton, Britania Raya yang bermain di Liga Utama Inggris. Klub ini memainkan pertandingan kandangnya di Stadion Molineux yang berkapasitas 32,050 penonton. Seragam mereka berwarna cokelat-hitam. Mereka dijuluki Wolves.",
            "Everton Football Club adalah sebuah klub sepak bola profesional yang bermarkas di Kota Liverpool, Inggris yang saat ini berkompetisi di Liga Premier, divisi teratas Liga Inggris. Klub ini merupakan rival dari klub sekota Liverpool. Klub ini adalah salah satu pendiri dari Liga Sepak bola Inggris dan telah berkompetisi di divisi teratas selama 117 musim sejak diciptakannya Liga Sepak bola Inggris, hanya melewatkan empat musim kompetisi papan atas (1930–31, 1951–52, 1952–53, 1953 –54).[2] Klub ini juga merupakan salah satu pendiri Liga Premier ketika dibentuk pada tahun 1992.",
            "Fullham Football Club adalah sebuah klub sepak bola Inggris yang didirikan pada tahun 1879. Klub ini bermarkas di daerah Fulham, London dan berkompetisi di Liga Utama Inggris. Fulham memainkan pertandingan kandangnya di Stadion Craven Cottage yang berkapasitas 25.700 kursi penonton dan saat ini sedang diperbesar sehingga akan berkapasitas 30.500 orang. Seragam mereka berwarna hitam-putih."
    };

    private static String [] clubJadwal ={
            "Arsenal v Manchester city, Premier League - Friday, May 5, 02:00",
            "Aston Villa v Chelsea, Premier League - Thursday, May 2, 22:00",
            "Chelsea v Aston Villa, Premier League - Thursday, May 2, 22:00",
            "Burnley v Fullham, Premier League - Saturday, May 6, 20:00",
            "Manchester United v Brighton, Premier League - Friday, May 5, 02:00",
            "Manchester City v Liverpool, Premier League - Sunday, May 7, 21:00",
            "Newcastle v Southampton, Premier League - Sunday, May 7, 21:00",
            "Liverpool v Manchester City, Premier League - Sunday, May 7, 21:00",
            "Southampton v Newcastle, Premier League - Sunday, May 7, 21:00",
            "Brighton v Manchester United, Premier League - Friday, May 5, 22:00",
            "Crystal Palace v Everton, Premier League - Friday, May 12, 02:00",
            "Leicester v Wolverhampton, Premier League - Thursday, May 9, 21:00",
            "Leeds v Tottenham Hotspur, Premier League - Thursday, May 9, 21:00",
            "Sheffield v Westbromwich Albion, Premier League - Sunday, May 14, 02:00",
            "Tottenham Hotspur v Leeds, Premier League - Thursday, May 9, 21:00",
            "Westbromwich Albion v Sheffield, Premier League - Sunday, May 14, 02:00",
            "Westham United v Newcastle, Premier League - Sunday, May 14, 02:00",
            "Wolverhampton v Leicester, Premier League - Thursday, May 9, 21:00",
            "Everton v Crystal Palace, Premier League - Friday, May 12, 02:00 ",
            "Fullham v Burnley, Premier League - Saturday, May 6, 20:00"
    };

    private static int[] clubImage ={
            R.drawable.arsenal,
            R.drawable.aston,
            R.drawable.chelsea,
            R.drawable.burnley,
            R.drawable.manutd,
            R.drawable.mancity,
            R.drawable.newcastle,
            R.drawable.liverpool,
            R.drawable.southampton,
            R.drawable.brighton,
            R.drawable.crystalpalace,
            R.drawable.leicester,
            R.drawable.leeds,
            R.drawable.sheffield,
            R.drawable.tottenham,
            R.drawable.westbromwich,
            R.drawable.westham,
            R.drawable.wolverhampton,
            R.drawable.everton,
            R.drawable.fullham

    };
    static ArrayList<Club> getListData(){
        ArrayList<Club> list = new ArrayList<>();
        for (int position = 0; position <clubName.length; position++) {
            Club club = new Club();
            club.setName(clubName[position]);
            club.setDetail(clubDetail[position]);
            club.setJadwal(clubJadwal[position]);
            club.setPhoto(clubImage[position]);
            list.add(club);
        }
        return list;
    }
}
