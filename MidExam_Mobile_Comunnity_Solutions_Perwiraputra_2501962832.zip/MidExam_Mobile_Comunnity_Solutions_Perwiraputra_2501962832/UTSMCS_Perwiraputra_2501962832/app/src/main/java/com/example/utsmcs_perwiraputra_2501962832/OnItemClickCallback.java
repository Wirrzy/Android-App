package com.example.utsmcs_perwiraputra_2501962832;

public interface OnItemClickCallback {
    void onItemClicked(Club club);
}
